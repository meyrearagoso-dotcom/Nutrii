# NutriConecta — Protótipo 1.0

Aplicação Next.js + TypeScript, responsiva, em azul e branco, com navegação entre os ambientes do nutricionista e do paciente.

## Requisitos
Node.js 20 ou superior e npm.

## Executar localmente
```bash
npm install
npm run dev
```
Abra http://localhost:3000 no navegador.

## O que funciona nesta demonstração
- Alternar entre os perfis de nutricionista e paciente (sem autenticação).
- Navegar entre as telas principais.
- Buscar pacientes cadastrados.
- Adicionar pacientes fictícios na memória do navegador (os dados desaparecem ao atualizar).
- Registrar consumo de água fictício durante a sessão.
- Enviar mensagens de demonstração na mesma página, sem rede ou persistência.
- Visualizar exemplos de cardápio, agenda e indicadores.

## Limitações importantes
**Não use dados reais de saúde neste protótipo.** Não há autenticação, banco de dados, proteção de prontuários ou envio real de mensagens. Todos os nomes, consultas e planos são fictícios. O conteúdo alimentar não é prescrição nutricional.

## Próximas etapas para produção
1. Criar banco PostgreSQL com migrações para usuários, pacientes, vínculos, prontuários, avaliações, planos, refeições, agenda e mensagens.
2. Implementar autenticação segura e autorização no servidor, com regras de acesso por paciente e profissional.
3. Implementar cadastro e atualização persistentes, com validação, logs de auditoria e histórico de planos.
4. Armazenar exames em buckets privados com URLs temporárias e regras estritas de acesso.
5. Implementar mensagens reais, notificações e agendamentos.
6. Realizar análise de riscos LGPD, controles de consentimento quando cabíveis, política de privacidade, retenção, backup e testes de segurança.
7. Validar cálculos, bases alimentares, prescrição e regras clínicas com nutricionista habilitado antes de liberar para pacientes.

## Organização
- `app/page.tsx`: interface e interações demonstrativas.
- `app/globals.css`: identidade visual e responsividade.
- `lib/demo.ts`: dados fictícios e tipos.

Este repositório é um ponto de partida para desenvolvimento, não um sistema clínico pronto para produção.


## Versão 2.0 — funcionalidades adicionadas

- Tela de anamnese com campos clínicos, objetivo e hábitos, selecionando paciente fictício.
- Avaliação antropométrica com peso, altura, cintura e quadril.
- Cálculo demonstrativo de IMC e histórico de avaliações por paciente.
- Tudo executado no navegador em memória: **não persiste após atualizar a página**.
- Nenhum serviço pago, chave de API ou banco de dados é necessário para testar.

**Segurança:** Esta versão não tem autenticação, isolamento real de pacientes, banco de dados nem prontuário eletrônico seguro. Use exclusivamente dados fictícios. Não utilize com pacientes reais nem insira dados sensíveis. Antes do uso clínico, implemente autenticação, autorização por usuário, proteção LGPD, trilhas de auditoria, backups e políticas de retenção.
