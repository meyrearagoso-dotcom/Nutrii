import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {title:'NutriConecta | Gestão nutricional',description:'Plataforma de acompanhamento nutricional'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body>{children}</body></html>}
